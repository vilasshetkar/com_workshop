<form name="upload" method="post" enctype="multipart/form-data">
<input type="file" name="file_upload" multiple />
<input type="submit" />
</form>