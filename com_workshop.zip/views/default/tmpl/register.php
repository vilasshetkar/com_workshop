<?php
// no direct access
defined('_JEXEC') or die;
JHtml::script(Juri::base() . 'components/com_workshop/js/script.js');
$document = JFactory::getDocument();
 
// Add Javascript directly here
$document->addScriptDeclaration('
    $(document).ready(function(){
		$("a").click(function(){
			//alert("An inline JavaScript Declaration");
		});
    });
');
?>


<?php $backlink = JRoute::_( "index.php?view=default"); ?>

<div class="">
<a href="<?php echo $backlink ; ?>" id="download-brochure" class="btn btn-primary"><span class="glyphicon glyphicon-chevron-left"></span> Event List</a>
</div>
<div class="clearfix"></div>
	<hr class="divider">



<?php foreach($this->property as $i => $row): ?>
<?php 
$id = ($row['title']);
$link = JRoute::_( "index.php?view=prop&id=".$id ); ?>

<h3 class="h3">Register for <?php echo $id; ?></h3>
<hr class="divider">
<div class="clearfix"></div>

<form class="form-horizontal" role="form">
  <div class="form-group">
    <label for="inputEmail3" class="col-lg-3 control-label">Name Of Program</label>
    <div class="col-lg-9">
      <input type="email" class="form-control" id="inputEmail3" placeholder="Name Of Program">
    </div>
  </div>
  <div class="form-group">
    <label for="start-date" class="col-lg-3 control-label">Date Of Program</label>
    <div class="col-lg-9" id="dp">
      <input type="text" class="form-control datepicker" id="start-date" placeholder="dd-mm-yyyy">
    </div>
  </div>
  <div class="form-group">
    <label for="venue" class="col-lg-3 control-label">Venue</label>
    <div class="col-lg-9">
      <textarea class="form-control" id="venue" name="venue" placeholder="Venue" rows="3"></textarea>
    </div>
    <!-- /.col-lg-4 --> 
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <label for="name" class="col-lg-3 control-label">Name of Participant</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="name" id="name" placeholder="Name of Participant">
    </div>
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <label for="designation" class="col-lg-3 control-label">Designation</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="name" id="designation" placeholder="Designation">
    </div>
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <label for="name of org" class="col-lg-3 control-label">Name Of The Organization</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="name" id="name of org" placeholder="Name Of The Organization">
    </div>
    <!-- /.col-lg-4 --> 
  </div>
  <!-- /.col-lg-4 -->
  
  <div class="form-group">
    <label for="orgaddr" class="col-lg-3 control-label">Organization Address</label>
    <div class="col-lg-9">
      <textarea class="form-control" id="orgaddr" name="venue" placeholder="Organization Address" rows="3"></textarea>
    </div>
    <!-- /.col-lg-4 --> 
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <label for="phone" class="col-lg-3 control-label">Phone Number</label>
    <div class="col-lg-9">
      <input type="tel" class="form-control" name="phone" id="phone" placeholder="Phone Number">
    </div>
    <!-- /.col-lg-4 --> 
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <label for="officenum" class="col-lg-3 control-label">Office Number</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="name" id="officenum" placeholder="Office Number">
    </div>
    <!-- /.col-lg-4 --> 
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" class="col-lg-3 control-label">Email Id</label>
    <div class="col-lg-9">
      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
    </div>
    <!-- /.col-lg-4 --> 
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <label for="resno" class="col-lg-3 control-label">Res No</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="name" id="resno" placeholder="Res NO">
    </div>
    <!-- /.col-lg-4 --> 
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <label for="paofres" class="col-lg-3 control-label">Present Area of Resposibility</label>
    <div class="col-lg-3">
      <div class="checkbox" id="paofres"> <span>
        <input type="checkbox">
        Production </span> </div>
    </div>
    <!-- /.col-lg-4 --> 
    <!-- /.col-lg-4 -->
    <div class="col-lg-3">
      <div class="checkbox"> <span>
        <input type="checkbox">
        Marketing </span> </div>
    </div>
    <!-- /.col-lg-4 -->
    <div class="col-lg-3">
      <div class="checkbox"> <span>
        <input type="checkbox">
        F&amp;A </span> </div>
    </div>
    <!-- /.col-lg-4 -->
    <div class="col-lg-3">
      <div class="checkbox"> <span>
        <input type="checkbox">
        HRD </span> </div>
    </div>
    <!-- /.col-lg-4 -->
    <div class="col-lg-3">
      <div class="checkbox"> <span>
        <input type="checkbox">
        SCM </span> </div>
    </div>
    <!-- /.col-lg-4 --> 
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2">
      <button type="submit" class="btn btn-default">Submit</button>
      <button type="reset" class="btn btn-default" id="resetme">Reset</button>
    </div>
    <!-- /.col-lg-4 --> 
    <!-- /.col-lg-4 --> 
  </div>
</form>
<hr class="divider">

<?php endforeach; ?>
