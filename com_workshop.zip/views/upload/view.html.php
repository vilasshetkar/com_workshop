<?php
defined('_JEXEC') or die;

jimport('joomla.application.component.viewlegacy');

class WorkShopViewUpload extends JViewLegacy
{
	 public function display($tpl = null)
	 {
		 // Display the template
		 parent::display($tpl);
	 }
	 
}
